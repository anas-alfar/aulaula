<?php
class get_questionnaire
{
    public $returned_q;
    public $index = 0;
    public $index2 = 0;
    public $index3 = 0;
    public $index4 = 0;
    public $index5 = 0;
    public $line_position = 690;
    public $questionText = array();
    public $questionType = array();


//Zend_Debug::dump($returned_q);

    public function __construct($questionnaire_num)
    {
       $questionnaire = new Questionnaire($questionnaire_num); //access questionnaire
       $this -> returned_q = $questionnaire ->  questions;
    }

     public function print_question($sectionID,$parent_qID,$questionID)
     { //print question to pdf
     include 'print_rough_question.php';
   // Zend_Debug::dump($this->returned_q[$sectionID]);

        if(isset($this->returned_q[$sectionID][$questionID]))
        {
            foreach($this->returned_q[$sectionID][$questionID] as $q_id=>$question)
            {
              //print_question($sectionID,$questionID,$q_id);
            }
        }
     }

    public function solve_array()
    {
   // echo 'function solve_array worked!';
      foreach($this->returned_q as $sectionID => $returned_q_by_section)
      {
          foreach($returned_q_by_section[0] as $id => $question)
          {

              $this->print_question($sectionID,0,$id);

          }
      }
    }
}
?>
