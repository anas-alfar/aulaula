<?php
require_once("QuestionnaireTable.php");
require_once("SectionTable.php");
require_once("Media.php");
require_once("Section.php");
require_once("QuestionnaireScore.php");
require_once("QuestionnaireScoreTable.php");
require_once("CustomQuestionnairesTable.php");
require_once("NameTextTable.php");
require_once("DescriptionTextTable.php");
require_once("SpecialtyQuestionnaireTable.php");
require_once("QuestionDateTime.php");
require_once("FavoriteQuestionnairesTable.php");
require_once("QuestionnaireTagsTable.php");
require_once("QuestionnaireTag.php");
require_once("QuestionTextBox.php");
require_once("QuestionScale.php");

class Questionnaire
{
	public $questionnaireId=null;
	public $questionnaireType=null;
	public $questionnaireTypeId=null;
	public $nameTextId=null;
	public $nameText=null;
	public $descriptionTextId=null;
	public $descriptionText=null;
	public $highScore=null;
	public $mediaId=null;
	public $printMediaId=null;
	public $isActive=null;
	public $isPublic=null;
	public $hasSupplemental;
	public $isSupplemental;
	public $supplementalParentId;
	public $canBeInstanced;
	public $isGrouped;
	public $showScoresAndResults=false;

	
	public $languageId=LanguageNames::LANGUAGE_ENGLISH; //languageId used to get the correct text for the questionnaire
						  //normally changed to the logged in user's language preference.

	private $sections = null;
	private $questions = null;
	private $media = null;
	private $printMedia = null;
	private $scores = null;
	private $specialtyNames=null;
	private $specialties=null;
	private $hasSummaries=null;
	
	private $primaryTag=null;
	private $primaryColorCode="#8e8e8e";
	private $tags=null;
	
	/**
	 * Constructor for Questionnaire class
	 *
	 * @param int $questionnaireId [optional]
	 */
	public function __construct($questionnaireId=null)
	{
		if(!empty($questionnaireId)){
			if(is_numeric($questionnaireId)){
				$this->fetchQuestionnaireDataById($questionnaireId);
			}
			else{
				throw new Exception("QuestionnaireId not numeric");
			}
		}
	}
	
	public function __get($key)
	{
		switch($key){
			case "questions":
				if(empty($this->questions)){
					return $this->returnQuestions();
				}else{
					return $this->questions;
				}
				break;
			case "sections":
				if(empty($this->sections)){
					return self::returnSections();
				}else{
					return $this->sections;
				}
				break;
			case "media":
				if(empty($this->media)){
					return self::returnMedia();
				}else{
					return $this->media;
				}
			case "printMedia":
				if(empty($this->printMedia)){
					return self::returnPrintMedia();
				}else{
					return $this->printMedia;
				}
			case "scores":
				if(empty($this->scores)){
					return self::returnScores();
				}else{
					return $this->scores;
				}
			case "specialtyNames":
				if(empty($this->specialtyNames)){
					return self::returnSpecialtyNames();
				}else{
					return $this->specialtyNames;
				}
			case "specialties":
				if(empty($this->specialties)){
					return self::returnSpecialties();
				}else{
					return $this->specialties;
				}
			case "isCustom":
				return $this->isGrouped;
			break;
			case "isHistory":
				if(!is_array($this->tags)) self::returnTags();
				return $this->primaryTag == "history";
			break;
			case "questionnaireClass":
				$classes = array('questionnaire-' . $this->questionnaireId);
				if($this->isHistory){
					$classes[] = 'history';
				}
				if($this->isCustom){
					$classes[] = 'custom';
				}
				return implode(' ',$classes);
			break;
			case "dotPrefix":
				//get the tags if the primary tag is not set.
				if(!is_array($this->tags)) self::returnTags();
				
				//VAP Compliance Icons.	
				if($this->primaryTag == "history")				//History Icon [H]
					return 'session-dot-hx';
				else if($this->primaryTag == "outcome")			//Outcome Icon [O]
					return 'session-dot-outcome';
				else if($this->primaryTag == "intake")			//Intake Icon [I]
					return 'session-dot-intake';
				else if($this->primaryTag == "experience")		//Experience/Satisfaction Icon [E]
					return 'session-dot-experience';
				else if($this->primaryTag == "specialty")		//Specialty Icon [S]
					return 'session-dot-specialty';
				else 
					return 'session-dot';						//Default Icon [-]
			break;
			case "hasSummaries":
				if(is_null($this->hasSummaries) || $this->hasSummaries==""){
					return self::returnHasSummaries();
				}else{
					return $this->hasSummaries;
				}
			break;
			case "tags":
				if(empty($this->tags)){
					return self::returnTags();
				}else{
					return $this->tags;
				}
			break;
			case "primaryTag":
				if(empty($this->primaryTag)){
					self::returnTags();
					return $this->primaryTag;
				}else{
					return $this->primaryTag;
				}
			break;
			case "primaryColorCode":
				if(empty($this->primaryColorCode)){
					self::returnTags();
					return $this->primaryColorCode;
				}else{
					return $this->primaryColorCode;
				}
			break;
			case "nameSlug":
				return Utilities::slug($this->nameText);
			break;
			default:
				throw new Exception("Value does not exist");
				break;
		}	
	}
	
	public static function getCustomQuestionnaires($personId, $doctorOnly=false)
	{
		$cTbl=new CustomQuestionnairesTable();
		$select=$cTbl->select()->setIntegrityCheck(false)->from("CustomQuestionnaires", null)
			->join("Questionnaire", "CustomQuestionnaires.QuestionnaireId = Questionnaire.QuestionnaireId")
			->join("NameText", "NameText.NameTextId = Questionnaire.NameTextId", "Name AS QuestionnaireName")
			->joinLeft("DescriptionText", "DescriptionText.DescriptionTextId = Questionnaire.DescriptionTextId")
			->join("QuestionnaireType", "QuestionnaireType.QuestionnaireTypeId = Questionnaire.QuestionnaireTypeId", "Name AS QuestoinnaireTypeName")
			->where("CustomQuestionnaires.PersonId = ?", $personId)
			->where("IsActive=1")
			->where("IsGrouped=0");
		
		if($doctorOnly){
			$select->where("Questionnaire.QuestionnaireTypeId=?",QuestionnaireTypeIds::DOCTOR_QUESTIONNAIRE);
		}
		$select->order("NameText.Name");
		
		$rows=$cTbl->fetchAll($select);
		$questionnaires=array();
		foreach($rows as $row)
		{
			$q = new Questionnaire();
			
			$q->questionnaireId = $row->QuestionnaireId;
			$q->questionnaireTypeId = $row->QuestionnaireTypeId;
			$q->nameTextId = $row->NameTextId;
			$q->descriptionTextId = $row->DescriptionTextId;
			$q->highScore = $row->HighScore;
			$q->mediaId=$row->MediaId;
			$q->isPublic=$row->IsPublic;
			$q->isActive=$row->IsActive;
			$q->hasSupplemental=$row->HasSupplemental;
			$q->isSupplemental=$row->IsSupplemental;
			$q->supplementalParentId=$row->SupplementalParentId;
			$q->canBeInstanced=$row->CanBeInstanced;
			$q->isGrouped=$row->IsGrouped;
			
			if($q->isGrouped)
			{
				$nameText = trim($row->QuestionnaireName, '[Patient]');
				$nameText = trim($nameText, '[Doctor]');
				$q->nameText=$nameText;
			}
			else
			{
				$q->nameText=$row->QuestionnaireName;
			}
			
			$q->descriptionText=$row->Description;
			$q->questionnaireType=$row->QuestoinnaireTypeName;

			$questionnaires[]=$q;
		}
		return $questionnaires;
	}
	
	public static function getSupplementalQuestionnaires($questionnaireId)
	{
		$questionnaires=array();
		if(!is_numeric($questionnaireId)){
			throw new Exception("QuestionnaireId not an Integer.");
		}else{ 
			$qTbl = new QuestionnaireTable(); //Data object
			$rows = $qTbl->findAllSupplementalQuestionnaires($questionnaireId);
			
			foreach($rows as $row)
			{
				$newQuestionnaire = new Questionnaire();
				
				//set the variables from the returned Questionnaire table row
				$newQuestionnaire->questionnaireId = $row->QuestionnaireId;
				$newQuestionnaire->questionnaireTypeId = $row->QuestionnaireTypeId;
				$newQuestionnaire->nameTextId = $row->NameTextId;
				$newQuestionnaire->descriptionTextId = $row->DescriptionTextId;
				$newQuestionnaire->highScore = $row->HighScore;
				$newQuestionnaire->mediaId=$row->MediaId;
				$newQuestionnaire->isPublic=$row->IsPublic;
				$newQuestionnaire->isActive=$row->IsActive;
				$newQuestionnaire->hasSupplemental=$row->HasSupplemental;
				$newQuestionnaire->isSupplemental=$row->IsSupplemental;
				$newQuestionnaire->supplementalParentId=$row->SupplementalParentId;
				$newQuestionnaire->canBeInstanced=$row->CanBeInstanced;
				
				if($row->NameTextId!=null)
				{
					//get the nameText row based off the relationship and the user's languageId
					$nameText=$row->findParentRow('NameTextTable',null,$qTbl->select()->where("LanguageId = ?",
						 $newQuestionnaire->languageId));
					$newQuestionnaire->nameText = $nameText->Name;
				}
				
				
				if($row->DescriptionTextId != null){
					//get the descriptionText row based off the relationship and the user's languageId
					$descriptionText = $row->findParentRow("DescriptionTextTable",null,$qTbl->select()->where("LanguageId=?",$newQuestionnaire->languageId));
					$newQuestionnaire->descriptionText = $descriptionText->Description;
				}
				
				//get the questionnairetype
				$questionnaireType = $row->findParentRow("QuestionnaireTypeTable");
				$newQuestionnaire->questionnaireType = $questionnaireType->Name;
				
				$questionnaires[] = $newQuestionnaire;
			}
			
			return $questionnaires;
		}
		return null;
	}
	
	/**
	 * Gets data for a given questionnaire given the questionnaireId
	 *
	 * @param integer $questionnaireId the questionnaireId to get information about
	 */
	public function fetchQuestionnaireDataById($questionnaireId)
	{
		if(!is_numeric($questionnaireId)){
			throw new Exception("QuestionnaireId not an Integer.");
		}else{
			$qTbl = new QuestionnaireTable(); //Data object
			$row=$qTbl->findQuestionnaireById($questionnaireId);
			if($row==null){ //if it didn't find a row, then there's no questionnaire for the given ID
				throw new Exception("Questionnaire not found.");
			}else{
				//set the variables from the returned Questionnaire table row
				$this->questionnaireId = $row->QuestionnaireId;
				$this->questionnaireTypeId = $row->QuestionnaireTypeId;
				$this->nameTextId = $row->NameTextId;
				$this->descriptionTextId = $row->DescriptionTextId;
				$this->highScore = $row->HighScore;
				$this->mediaId=$row->MediaId;
				$this->isPublic=$row->IsPublic;
				$this->isActive=$row->IsActive;
				$this->hasSupplemental=$row->HasSupplemental;
				$this->isSupplemental=$row->IsSupplemental;
				$this->supplementalParentId=$row->SupplementalParentId;
				$this->canBeInstanced=$row->CanBeInstanced;
				$this->isGrouped=$row->IsGrouped;
				$this->showScoresAndResults=$row->ShowScoresAndResults;
				$this->printMediaId=$row->PrintMediaId;
				
				if(isset($row->NameText, $row->DescriptionText, $row->QuestionnaireType)){
					$this->nameText=$row->NameText;
					$this->descriptionText=$row->DescriptionText;
					$this->questionnaireType=$row->QuestionnaireType;
				}
				
				/*
				if($row->NameTextId!=null)
				{
					//get the nameText row based off the relationship and the user's languageId
					$nameText=$row->findParentRow('NameTextTable',null,$qTbl->select()->where("LanguageId = ?",
						 $this->languageId));
					
					if($this->isGrouped)
					{
						$nameText = trim($nameText->Name, '[Patient]');
						$nameText = trim($nameText, '[Doctor]');
						$this->nameText=$nameText;
					}
					else
					{
						$this->nameText=$nameText->Name;
					}
				}
				
				
				if($row->DescriptionTextId != null){
					//get the descriptionText row based off the relationship and the user's languageId
					$descriptionText = $row->findParentRow("DescriptionTextTable",null,$qTbl->select()->where("LanguageId=?",$this->languageId));
					$this->descriptionText = $descriptionText->Description;
				}
				
				//get the questionnairetype
				$questionnaireType = $row->findParentRow("QuestionnaireTypeTable");
				$this->questionnaireType = $questionnaireType->Name;
				*/
			}
		}
	}
	
	private function returnScores()
	{
		if(empty($this->scores)){
			$this->scores=array();
			$qTbl=new QuestionnaireScoreTable();
			$rows=$qTbl->getByQuestionnaireId($this->questionnaireId);
			foreach($rows as $row){
				$q=new QuestionnaireScore();
				$q->getFromDBRow($row);
				
				$this->scores[]=$q;
			}
		}
	
		return $this->scores;
	}
	
	private function returnMedia()
	{
		if(!empty($this->mediaId)){
			$m=new Media($this->mediaId);
			$this->media=$m;
			
			return $this->media;
		}else{
			return null;
		}
	}
	
	private function returnPrintMedia()
	{
		if(!empty($this->printMediaId)){
			$m=new Media($this->printMediaId);
			$this->printMedia=$m;
			
			return $this->printMedia;
		}else{
			return null;
		}
	}
	
	/**
	 * Gets all sections that this questionnaire has and
	 * stores them into an array of sections
	 *
	 */
	public function returnSections($sectionId=-1)
	{
		$this->sections=array();
		if($this->questionnaireId == null){
			throw new Exception("QuestionnaireId is null.");
		}else{
			$sTbl=new SectionTable();
			if($sectionId > 0){
				$rows=$sTbl->getSectionsById($sectionId);
			}else{
				$rows=$sTbl->getSectionsByQuestionnaireId($this->questionnaireId);
			}
			
			foreach($rows as $row)
			{
				$s=new Section();
				$s->getFromDBRow($row);
				/*
				$s->sectionId=$row->SectionId;
				$s->descriptionTextId=$row->DescriptionTextId;
				$s->instructionsTextId=$row->InstructionsTextId;
				$s->nameTextId=$row->NameTextId;
				$s->questionnaireId=$row->QuestionnaireId;
				$s->rank=$row->Rank;
				$s->isCarousel=$row->IsCarousel;
				
				Section::getForeignKeys($s, $row);
				*/
				$this->sections[]=$s; //add it to the array
			}
		}
		return $this->sections;
	}
	public static function getNewQuestionByTypeStatic($type){
		switch($type){
			case QuestionTypeNames::QUESTION_TYPE_TRUE_FALSE:
			case QuestionTypeNames::QUESTION_TYPE_COMPOSITE:
			case QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE:
			case QuestionTypeNames::QUESTION_TYPE_SCALE:
			case QuestionTypeNames::QUESTION_TYPE_FREE_RESPONSE:
			case QuestionTypeNames::QUESTION_TYPE_TEXTBOX_WITH_LABEL:
			case QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE_WITH_CHOOSE_ALL_THAT_APPLY:
			case QuestionTypeNames::QUESTION_TYPE_LESION:
				return new Question();
			break;
			case QuestionTypeNames::QUESTION_TYPE_ANATOMY:
				return new QuestionAnatomy();
			break;
			case QuestionTypeNames::QUESTION_TYPE_AVATAR:
				return new QuestionAvatar();
			break;
			case QuestionTypeNames::QUESTION_TYPE_DATE_TIME:
				return new QuestionDateTime();
			break;
			default:
				return new Question();
			break;
		}
	}
	public function getNewQuestionByType($type){
		switch($type){
			case QuestionTypeNames::QUESTION_TYPE_TRUE_FALSE:
			case QuestionTypeNames::QUESTION_TYPE_COMPOSITE:
			case QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE:
			case QuestionTypeNames::QUESTION_TYPE_SCALE:
			case QuestionTypeNames::QUESTION_TYPE_FREE_RESPONSE:
			case QuestionTypeNames::QUESTION_TYPE_TEXTBOX_WITH_LABEL:
			case QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE_WITH_CHOOSE_ALL_THAT_APPLY:
			case QuestionTypeNames::QUESTION_TYPE_LESION:
				return new Question();
			break;
			case QuestionTypeNames::QUESTION_TYPE_ANATOMY:
				return new QuestionAnatomy();
			break;
			case QuestionTypeNames::QUESTION_TYPE_AVATAR:
				return new QuestionAvatar();
			break;
			case QuestionTypeNames::QUESTION_TYPE_DATE_TIME:
				return new QuestionDateTime();
			break;
			default:
				return new Question();
			break;
		}
	}
	public function returnQuestions(){
		$qs = array();
		$data = $this->getAllQuestionRows();
		$sI = 0;
		$qI = 0;
		foreach($data as $d){
			$nq = $this->getNewQuestionByType($d->QuestionType);
			$nq->getFromDBRowAll($d);
			if(!$nq->hasParentQuestion()){
				$parentId = 0;
			}else{
				$parentId = $nq->parentId;
			}
			if(isset($flat)){
				if(!isset($qs[$sI][$qI])){
					$qs[$nq->sectionId][$parentId] = array();
				}
				$qs[$nq->sectionId][$parentId][$nq->questionId] = $nq;
				$sI++;
				$qI++;
			}else{
				if(!isset($qs[$nq->sectionId][$parentId])){
					$qs[$nq->sectionId][$parentId] = array();
				}
				$qs[$nq->sectionId][$parentId][$nq->questionId] = $nq;
			}
		}
		return $qs;
	}
	public function getAllQuestionRows(){
		$qTbl=new QuestionTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from(array("Q"=>"Questionnaire"))
				->joinLeft(array("S"=>"Section"), "Q.QuestionnaireId = S.QuestionnaireId", NULL)
				->joinLeft(array("Qu"=>"Question"), "Qu.SectionId = S.SectionId AND Qu.IsDeleted = 0", '*')
				->joinLeft(array("NT"=>"NameText"), "Qu.NameTextId = NT.NameTextId", array("QuestionText"=>"Name"))
				->joinLeft(array("ST"=>"NameText"), "Qu.SummaryTitleId=ST.NameTextId", array("SummaryTitle"=>"Name"))
				->joinLeft(array("QT"=>"QuestionType"), "Qu.QuestionTypeId = QT.QuestionTypeId", array("QuestionType"=>"Name"))
				->joinLeft(array("AQ"=>"AlternativeQuestion"), "Qu.QuestionId = AQ.ChildQuestionId", array("AlternativeParentId"=>"AQ.ParentQuestionId"))
				->joinLeft(array("NTA"=>"NoToAllQuestion"), "Qu.QuestionId = NTA.ChildQuestionId", array("NoToAllParentId"=>"NTA.ParentQuestionId"))
				->joinLeft(array("QDT"=>"QuestionDateTime"), "QDT.QuestionId = Qu.QuestionId",
						   array("ShowDay"=>"QDT.ShowYear","ShowMonth"=>"QDT.ShowMonth","ShowYear"=>"QDT.ShowYear","ShowTime"=>"QDT.ShowTime","AllowMultiple"=>"QDT.AllowMultiple", "AllowFutureDate"=>"QDT.AllowFutureDate"))
				->where("Q.QuestionnaireId=?", (int) $this->questionnaireId)
				->order('S.Rank')
				->order('Qu.Rank');
		return $qTbl->fetchAll($select);
	}
	public function getAllQuestionIds()
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from("Questionnaire", '*')
			->joinLeft("Section", "Questionnaire.QuestionnaireId=Section.QuestionnaireId", '*')
			->joinLeft("Question", "Section.SectionId=Question.SectionId AND Question.IsDeleted = 0", '*')
			->where("Questionnaire.QuestionnaireId=?",$this->questionnaireId);
		$rows = $qTbl->fetchAll($select);
		$questionIds=array();
		foreach($rows as $row){
			$questionIds[]=$row->QuestionId;
		}
		return $questionIds;
	}
	
	public function getAlternativeQuestionData($questionId=-1)
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from(array("Q"=>"Questionnaire"), NULL)
			->joinLeft(array("S"=>"Section"), "Q.QuestionnaireId=S.QuestionnaireId", NULL)
			->joinLeft(array("Qu"=>"Question"), "S.SectionId=Qu.SectionId AND Qu.IsDeleted = 0", NULL)
			->joinLeft(array("AQ"=>"AlternativeQuestion"), "Qu.QuestionId=AQ.ParentQuestionId", NULL)
			->joinLeft(array("AMC"=>"AlternativeMCResponse"), "AQ.AlternativeQuestionId=AMC.AlternativeQuestionId", array("AlternativeQuestionId", "MultipleChoiceId"))
			->joinLeft(array("MC"=>"MultipleChoice"), "AMC.MultipleChoiceId=MC.MultipleChoiceId", NULL)
			->joinLeft(array("NT"=>"NameText"), "MC.NameTextId=NT.NameTextId", array("Name"))
			->where("Q.QuestionnaireId=?", $this->questionnaireId)
			->where("AMC.MultipleChoiceId IS NOT NULL");
		if($questionId > 0){
			$select->where("Qu.QuestionId=?",$questionId);
		}
		$rows=$qTbl->fetchAll($select);
		$data=array();
		foreach($rows as $row){
			if(!isset($data[$row->AlternativeQuestionId])){
				$data[$row->AlternativeQuestionId]=array();
			}
			
			$data[$row->AlternativeQuestionId][$row->MultipleChoiceId]=$row->Name;
		}
		return $data;
	}
	public function getAlternativeQuestionDataByChild()
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from(array("Q"=>"Questionnaire"), NULL)
			->joinLeft(array("S"=>"Section"), "Q.QuestionnaireId=S.QuestionnaireId", NULL)
			->joinLeft(array("Qu"=>"Question"), "S.SectionId=Qu.SectionId AND Qu.IsDeleted = 0", NULL)
			->joinLeft(array("AQ"=>"AlternativeQuestion"), "Qu.QuestionId=AQ.ParentQuestionId", array("ParentQuestionId","ChildQuestionId","NeededBoolResponse"))
			->joinLeft(array("AMC"=>"AlternativeMCResponse"), "AQ.AlternativeQuestionId=AMC.AlternativeQuestionId", array("AlternativeQuestionId", "MultipleChoiceId"))
			->joinLeft(array("MC"=>"MultipleChoice"), "AMC.MultipleChoiceId=MC.MultipleChoiceId", NULL)
			->joinLeft(array("NT"=>"NameText"), "MC.NameTextId=NT.NameTextId", array("Name"))
			->where("Q.QuestionnaireId=?", $this->questionnaireId);
			//->where("AMC.MultipleChoiceId IS NOT NULL");
		$rows=$qTbl->fetchAll($select);
		$data=array();
		foreach($rows as $row){
			if(!isset($data[$row->ChildQuestionId])){
				$data[$row->ChildQuestionId]=array();
			}
			if(isset($row->MultipleChoiceId) && $row->MultipleChoiceId){
				$data[$row->ChildQuestionId][$row->MultipleChoiceId]=$row->Name;
			}else{
				$nr = 0;
				if(isset($row->NeededBoolResponse)){
					if($row->NeededBoolResponse){
						$nr = $row->NeededBoolResponse;
					}
				}
				$data[$row->ChildQuestionId][$nr]="YesNo";
			}
		}
		return $data;
	}
	
	public function getAllMultipleChoiceGroups(){
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->distinct(true)->from("Questionnaire", NULL)
			->join("Section", "Questionnaire.QuestionnaireId=Section.QuestionnaireId", NULL)
			->join("Question", "Section.SectionId = Question.SectionId AND Question.IsDeleted = 0", NULL)
			->join("QuestionMultipleChoice", "Question.QuestionId=QuestionMultipleChoice.QuestionId")
			->join("MultipleChoiceGroup", "QuestionMultipleChoice.MultipleChoiceGroupId=MultipleChoiceGroup.MultipleChoiceGroupId")
			->join("MultipleChoice", "MultipleChoiceGroup.MultipleChoiceGroupId=MultipleChoice.MultipleChoiceGroupId")
			->join("NameText", "MultipleChoice.NameTextId=NameText.NameTextId")
			->where("Questionnaire.QuestionnaireId=?", $this->questionnaireId)
			->order(array("QuestionId", "MultipleChoice.MultipleChoiceGroupId", "MultipleChoice.Rank ASC"));
		$rows=$qTbl->fetchAll($select);
		if(!isset(Register::getInstance()->multipleChoiceData) || !is_array(Register::getInstance()->multipleChoiceData)){
			Register::getInstance()->multipleChoiceData=array();
		}
		$currentQuestionId=0;
		$currentMultipleChoiceGroupId=0;
		$currentQC=null;
		foreach($rows as $row){
			//if we're at a new question
			if($row->QuestionId != $currentQuestionId){
				Register::getInstance()->multipleChoiceData[$currentQuestionId]=$currentQC;
				$currentQuestionId=$row->QuestionId;
				$currentQC=new QuestionChoices();
				$currentQC->questionId=$currentQuestionId;
			}
			$c=new Choice($row->Name, $row->MultipleChoiceId);
			$currentQC->choices[]=$c;
		}
	}
	
	/**
	 * Gets all alternative questions and their associated question data
	 * for the entire questionnaire.
	 */
	public function getAllAlternativeQuestions()
	{
		$data=array();
		$qTbl=new QuestionTable();
			
		$select = $qTbl->select()->setIntegrityCheck(false);
		$select->from(array("AlternativeQuestion"))
			->joinLeft("Question", "AlternativeQuestion.ChildQuestionId=Question.QuestionId AND Question.IsDeleted = 0")
			->joinLeft("NameText", "Question.NameTextId=NameText.NameTextId", array("QuestionText"=>"Name"))
			->joinLeft(array("ST"=>"NameText"), "Question.SummaryTitleId=ST.NameTextId", array("SummaryTitle"=>"Name"))
			->joinLeft("QuestionType", "Question.QuestionTypeId=QuestionType.QuestionTypeId", 
				array("QuestionType.Name as QuestionType"))
			->joinLeft("Section", "Question.SectionId=Section.SectionId")
			->where("Section.QuestionnaireId=?", $this->questionnaireId)
			->order("Question.Rank ASC");
		$rows=$qTbl->fetchAll($select);
		
		$aTbl=new AlternativeMCResponseTable();
		$mTbl=new MultipleChoiceTable();
		foreach($rows as $row)
		{
			$q = new Question();
			$q->questionId=$row->QuestionId;
			$q->sectionId=$row->SectionId;
			$q->hasAlternative=$row->HasAlternative;
			$q->isAlternative=$row->IsAlternative;
			$q->nameTextId=$row->NameTextId;
			$q->rank=$row->Rank;
			$q->assignsQuestionnaire=$row->AssignsQuestionnaire;
			
			//if neededBoolResponse is not null, we only need a 1 or 0 to show the alternative question.
			//if it is null, we need to grab the MCIds that trigger the alternative question.
			if($row->NeededBoolResponse !== NULL){// || $row->NeededBoolResponse == 0){
				$q->neededResponse[]=$row->NeededBoolResponse;
				if($row->NeededBoolResponse)
					$q->neededResponseNames[]='Yes';
				else
					$q->neededResponseNames[]='No';
			}else{
				if(isset(Register::getInstance()->alternativeData)){
					foreach(Register::getInstance()->alternativeData[$row->AlternativeQuestionId] as $multipleChoiceId=>$name){
						$q->neededResponse[]=$multipleChoiceId;
						$q->neededResponseNames[]=$name;
					}
				}else{
					$rows2=$aTbl->getMCIdsFromAlternativeId($row->AlternativeQuestionId);
					foreach($rows2 as $row2){
						$q->neededResponse[]=$row2->MultipleChoiceId;
						$row3=$mTbl->getById($row2->MultipleChoiceId);
						$q->neededResponseNames[]=$row3->Name;
					}
				}
			}
			$q->questionTypeId=$row->QuestionTypeId;
			$q->questionType=$row->QuestionType;
			$q->isColorRated=$row->IsColorRated;
			$q->startGreen=$row->StartGreen;
			$q->isNoToAll=$row->IsNoToAll;
			//$q->compositeTypeId=$row->CompositeTypeId;
			$q->hasNoToAllParent=$row->HasNoToAllParent;
			$q->summaryTitleId=$row->SummaryTitleId;
			if(isset($row->SummaryTitle)){
				$q->summaryTitle=$row->SummaryTitle;
			}
			
			$q->questionText=$row->QuestionText;
			
			$data[$row->ParentQuestionId][]=$q;
		}
		return $data;
	}
	
	public function getQuestionTypes()
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from(array("Q"=>"Questionnaire"), NULL)
			->joinLeft(array("S"=>"Section"), "Q.QuestionnaireId=S.QuestionnaireId", NULL)
			->joinLeft(array("Qu"=>"Question"), "S.SectionId=Qu.SectionId AND Qu.IsDeleted = 0", array("QuestionId"))
			->joinLeft(array("QT"=>"QuestionType"), "Qu.QuestionTypeId=QT.QuestionTypeId", array("Name"));
		
		$rows=$qTbl->fetchAll($select);
		
		$data=array();
		foreach($rows as $row)
		{
			$data[$row->QuestionId]=$row->Name;
		}
		
		return $data;
	}
	
	public function getQuestionTypeData($questionId=-1)
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from(array("Q"=>"Questionnaire"), NULL)
			->joinLeft(array("S"=>"Section"), "Q.QuestionnaireId = S.QuestionnaireId", NULL)
			->joinLeft(array("Qu"=>"Question"), "S.SectionId=Qu.SectionId AND Qu.IsDeleted = 0", array("QuestionId"))
			->joinLeft(array("QT"=>"QuestionType"), "Qu.QuestionTypeId=QT.QuestionTypeId", array("QuestionType"=>"Name"))
			->joinLeft(array("QMC"=>"QuestionMultipleChoice"), "Qu.QuestionId=QMC.QuestionId", array("MultipleChoiceGroupId"))
			->joinLeft(array("QTB"=>"QuestionTextBox"), "Qu.QuestionId=QTB.QuestionId", array("MaxLength", "Size", "RegularExpressionGroupId", "CustomInputTypeId"))
			->joinLeft(array("QDL"=>"QuestionDataList"), "Qu.QuestionId=QDL.QuestionId", array("DataListTypeId"))
			->joinLeft(array("DLT"=>"DataListType"), "QDL.DataListTypeId=DLT.DataListTypeId", array("DataListTypeName"=>"Name","DataListTypeGateway"=>"Gateway"))
			->joinLeft(array("CIT"=>"CustomInputType"), "QTB.CustomInputTypeId=CIT.CustomInputTypeId", array("CustomInputType"=>"Type"))
			->joinLeft(array("QDT"=>"QuestionDateTime"), "Qu.QuestionId=QDT.QuestionId", array("ShowYear", "ShowMonth", "ShowDay", "ShowTime", "AllowMultiple", "AllowFutureDate"))
			->joinLeft(array("NT"=>"NameText"), "QTB.NameTextId = NT.NameTextId", array("TextBoxLabel"=>"Name"))
			->joinLeft(array("QS"=>"QuestionScale"), "Qu.QuestionId=QS.QuestionId", array("StartValue", "EndValue"))
			->joinLeft(array("NT2"=>"NameText"), "QS.StartNameTextId=NT2.NameTextId", array("StartText"=>"Name"))
			->joinLeft(array("NT3"=>"NameText"), "QS.EndNameTextId=NT3.NameTextId", array("EndText"=>"Name"))
			->where("Q.QuestionnaireId=?", $this->questionnaireId);
		if($questionId > 0){
			$select->where("Qu.QuestionId=?",$questionId);
		}
		$rows=$qTbl->fetchAll($select);
		
		$data=array();
		foreach($rows as $row){
			if($row->QuestionType==QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE || $row->QuestionType==QuestionTypeNames::QUESTION_TYPE_MULTIPLE_CHOICE_WITH_CHOOSE_ALL_THAT_APPLY){
				$data[$row->QuestionId]=$row->MultipleChoiceGroupId;
			}else if($row->QuestionType==QuestionTypeNames::QUESTION_TYPE_FREE_RESPONSE || $row->QuestionType==QuestionTypeNames::QUESTION_TYPE_TEXTBOX_WITH_LABEL){
				$tb=new QuestionTextBox();
				$tb->size=$row->Size;
				$tb->questionId=$row->QuestionId;
				$tb->maxLength=$row->MaxLength;
				$tb->labelText=$row->TextBoxLabel;
				$tb->customInputTypeId=$row->CustomInputTypeId;
				$tb->customInputType=$row->CustomInputType;
				$tb->regularExpressionGroupId=$row->RegularExpressionGroupId;
				if($tb->regularExpressionGroupId!=NULL){
					$tb->getRegularExpressionGroup();
				}
				$data[$row->QuestionId]=$tb;
			}else if($row->QuestionType==QuestionTypeNames::QUESTION_TYPE_SCALE){
				$qs=new QuestionScale();
				$qs->questionId=$row->QuestionId;
				$qs->startValue=$row->StartValue;
				$qs->endValue=$row->EndValue;
				$qs->startText=$row->StartText;
				$qs->endText=$row->EndText;
				$data[$row->QuestionId]=$qs;
			}else if($row->QuestionType==QuestionTypeNames::QUESTION_TYPE_DATE_TIME){
				$dt=new QuestionDateTime();
				$dt->questionId=$row->QuestionId;
				$dt->allowMultiple=$row->AllowMultiple;
				$dt->allowFutureDate=$row->AllowFutureDate;
				$dt->showYear=$row->ShowYear;
				$dt->showMonth=$row->ShowMonth;
				$dt->showDay=$row->ShowDay;
				$dt->showTime=$row->ShowTime;
				$data[$row->QuestionId]=$dt;
			}
		}
		
		return $data;
			
	}
	
	public function doesPersonHaveAccess($personId)
	{
		if($this->isPublic){
			return true;
		}else{
			$cTbl=new CustomQuestionnairesTable();
			$select=$cTbl->select()->where("PersonId=?",$personId)
				->where("QuestionnaireId=?",$this->questionnaireId);
			$rows=$cTbl->fetchAll($select);
			return count($rows)>0;
		}
	}
	
	public function getAllQuestionnaires($withCustom=false, $doctorOnly=false)
	{
		$qt = new QuestionnaireTable();
		$questionnaires = $qt->findAllQuestionnaires($withCustom, $doctorOnly);
		$myQs = array();
		foreach($questionnaires as $q)
		{
			$thisQ = new Questionnaire();
			$thisQ->fetchQuestionnaireDataById($q->QuestionnaireId);
			array_push($myQs, $thisQ);
		}

		return $myQs;
	}
	
	public function getAllQuestionnairesDebug()
	{
		$myQs = array_merge($this->getAllQuestionnaires(true),$this->getAllQuestionnaires(false));
		sort($myQs);
		return $myQs;
	}
	
	public static function createNew($questionnaireName, $questionnaireDescription, $questionnaireTypeId, $mediaId, $isPublic, $isActive=true)
	{
		$languageId=LanguageNames::LANGUAGE_ENGLISH;
		$nTbl=new NameTextTable();
		$nameTextId=$nTbl->insertNewOverlapCheck($languageId, $questionnaireName);
		
		$dTbl=new DescriptionTextTable();
		$descriptionTextId=$dTbl->insertNewOverlapCheck($languageId, $questionnaireDescription);
	
		
		$qTbl=new QuestionnaireTable();
		$questionnaireId = $qTbl->insert(array("QuestionnaireTypeId"=>$questionnaireTypeId, "NameTextId"=>$nameTextId, "DescriptionTextId"=>$descriptionTextId, "MediaId"=>$mediaId,
			"IsPublic"=>$isPublic, "IsActive"=>$isActive));

		return $questionnaireId;
	}
	
	public static function saveQuestionnaire($questionnaireId, $questionnaireName, $questionnaireDescription, $questionnaireTypeId, $mediaId, $isPublic, $isActive=true){
		
		$questionnaireId=(int)$questionnaireId;
		$languageId=LanguageNames::LANGUAGE_ENGLISH;
		
		$nTbl=new NameTextTable();
		$nameTextId=$nTbl->insertNewOverlapCheck($languageId, $questionnaireName);
	
		$dTbl=new DescriptionTextTable();
		$descriptionTextId=$dTbl->insertNewOverlapCheck($languageId, $questionnaireDescription);
		
		$qTbl=new QuestionnaireTable();
		$row=$qTbl->find($questionnaireId)->current();
				
		if(!empty($row)){
		  $row->NameTextId=$nameTextId;
		  $row->DescriptionTextId=$descriptionTextId;
		  $row->QuestionnaireTypeId=$questionnaireTypeId;
		  $row->MediaId=$mediaId;
		  $row->IsPublic=$isPublic;
		  $row->IsActive=$isActive;
					  
		  $row->save();
		  
		  return $questionnaireId;
		}else{
		  throw new Exception("Questionnaire does not exist");	
		}
	}
	
	public static function getHasAlternativeQuestions($questionnaireId)
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from("Questionnaire", null)
			->joinLeft("Section", "Questionnaire.QuestionnaireId=Section.QuestionnaireId", null)
			->joinLeft("Question", "Section.SectionId=Question.SectionId AND Question.IsDeleted = 0", array("QuestionId","Rank"))
			->joinLeft("NameText", "Question.NameTextId=NameText.NameTextId", "Name")
			->where("Question.QuestionTypeId=1 OR Question.QuestionTypeId=4 OR Question.QuestionTypeId=8")
			->where("Question.hasAlternative=1")
			->where("Questionnaire.QuestionnaireId=?",$questionnaireId);
		$rows=$qTbl->fetchAll($select);
		return $rows;
	}
	
	public static function getNoToAllQuestions($questionnaireId)
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from("Questionnaire", null)
			->joinLeft("Section", "Questionnaire.QuestionnaireId=Section.QuestionnaireId", null)
			->joinLeft("Question", "Section.SectionId=Question.SectionId AND Question.IsDeleted = 0", array("QuestionId","Rank"))
			->joinLeft("NameText", "Question.NameTextId=NameText.NameTextId", "Name")
			->where("Question.QuestionTypeId=4")
			->where("Question.IsNoToAll=1")
			->where("Questionnaire.QuestionnaireId=?",$questionnaireId);
		$rows=$qTbl->fetchAll($select);
		return $rows;
	}
	public static function getJSON($questionnaireId){
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from("Questionnaire", null)
			->joinLeft("Section", "Questionnaire.QuestionnaireId=Section.QuestionnaireId")
			->joinLeft("Question", "Section.SectionId=Question.SectionId AND Question.IsDeleted = 0") //, array("QuestionId","Rank"))
			->joinLeft("NameText", "Question.NameTextId=NameText.NameTextId", "Name")
			//->where("Question.QuestionTypeId=1 OR Question.QuestionTypeId=4 OR Question.QuestionTypeId=8")
			//->where("Question.hasAlternative=1")
			->where("Questionnaire.QuestionnaireId=?",$questionnaireId);
		$rows=$qTbl->fetchAll($select);
		
		return "test";
	}
	
	private function returnSpecialtyNames()
	{
		$this->specialtyNames=array();
		if($this->questionnaireId == null){
			throw new Exception("QuestionnaireId is null.");
		}else{
			$sqTbl = new SpecialtyQuestionnaireTable();
			$rows = $sqTbl->getSpecialtiesByQuestionnaire($this->questionnaireId);
			
			foreach($rows as $row)
			{
				$this->specialtyNames[]=$row->Name;
			}
		}
		return $this->specialtyNames;
	}
	
	private function returnSpecialties()
	{
		$this->specialties=array();
		if($this->questionnaireId == null){
			throw new Exception("QuestionnaireId is null.");
		}else{
			$sqTbl = new SpecialtyQuestionnaireTable();
			$rows = $sqTbl->getSpecialtiesByQuestionnaire($this->questionnaireId);
			
			foreach($rows as $row)
			{
				$specialtyId=(int)$row->SpecialtyId;
				$this->specialties[]=new Specialty($specialtyId);
			}
		}
		return $this->specialties;
	}
	
	public static function getFavoriteQuestionnaires($personId, $doctorOnly=false)
	{
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->setIntegrityCheck(false)->from("Questionnaire")
			->join("FavoriteQuestionnaires", "FavoriteQuestionnaires.QuestionnaireId = Questionnaire.QuestionnaireId", null)
			->join("NameText", "NameText.NameTextId = Questionnaire.NameTextId", "Name AS QuestionnaireName")
			->where("FavoriteQuestionnaires.PersonId = ?", $personId)
			->where("IsActive=1")
			->where("IsGrouped=0");
			
		if($doctorOnly){
			$select->where("Questionnaire.QuestionnaireTypeId=?",QuestionnaireTypeIds::DOCTOR_QUESTIONNAIRE);
		}
		$select->order("NameText.Name");
			
		$rows=$qTbl->fetchAll($select);
		$questionnaires=array();
		foreach($rows as $row)
		{
			$q = new Questionnaire();
			$q->getDataByDBRow($row);

			$questionnaires[]=$q;
		}
		return $questionnaires;
	}
	
	public function getDataByDBRow($row)
	{
		if($row instanceOf Zend_Db_Table_Row_Abstract )
		{
			$this->questionnaireId = $row->QuestionnaireId;
			$this->questionnaireTypeId = $row->QuestionnaireTypeId;
			$this->nameTextId = $row->NameTextId;
			$this->descriptionTextId = $row->DescriptionTextId;
			$this->highScore = $row->HighScore;
			$this->mediaId=$row->MediaId;
			$this->isPublic=$row->IsPublic;
			$this->isActive=$row->IsActive;
			$this->hasSupplemental=$row->HasSupplemental;
			$this->isSupplemental=$row->IsSupplemental;
			$this->supplementalParentId=$row->SupplementalParentId;
			$this->canBeInstanced=$row->CanBeInstanced;
			$this->isGrouped=$row->IsGrouped;
			
			if(isset($row->Name, $row->Description, $row->QuestionnaireType)){
				$this->nameText=$row->Name;
				$this->descriptionText=$row->Description;
				$this->questionnaireType=$row->QuestionnaireType;
			}else{
				Questionnaire::getForeignKeys($this,$row);
			}
		}
	}
	
	public static function getForeignKeys($object,$row)
	{
		if($object instanceOf Questionnaire && $row instanceOf Zend_Db_Table_Row_Abstract )
		{
			$qTbl=new QuestionnaireTable();
			if($row->NameTextId!=null)
			{
				//get the nameText row based off the relationship and the user's languageId
				$nameText=$row->findParentRow('NameTextTable',null,$qTbl->select()->where("LanguageId = ?",
					 $object->languageId));
				
				if($object->isGrouped)
				{
					$nameText = trim($nameText->Name, '[Patient]');
					$nameText = trim($nameText, '[Doctor]');
					$object->nameText=$nameText;
				}
				else
				{
					$object->nameText=$nameText->Name;
				}
			}
			
			
			if($row->DescriptionTextId != null){
				//get the descriptionText row based off the relationship and the user's languageId
				$descriptionText = $row->findParentRow("DescriptionTextTable",null,$qTbl->select()->where("LanguageId=?",$object->languageId));
				$object->descriptionText = $descriptionText->Description;
			}
			
			//get the questionnairetype
			$questionnaireType = $row->findParentRow("QuestionnaireTypeTable");
			$object->questionnaireType = $questionnaireType->Name;
		}
	}
	
	public static function getCustomQuestionnairesByClinic($clinicId)
	{
		$roleId=Role::getByName(RoleNames::ROLE_DOCTOR)->roleId;
		$qTbl=new QuestionnaireTable();
		$select=$qTbl->select()->distinct()->setIntegrityCheck(false)->from("Questionnaire")
			->join("CustomQuestionnaires", "CustomQuestionnaires.QuestionnaireId = Questionnaire.QuestionnaireId", null)
			->join("NameText", "NameText.NameTextId = Questionnaire.NameTextId", "Name AS QuestionnaireName")
			->joinLeft("DescriptionText", "DescriptionText.DescriptionTextId = Questionnaire.DescriptionTextId")
			->join("QuestionnaireType", "QuestionnaireType.QuestionnaireTypeId = Questionnaire.QuestionnaireTypeId", "Name AS QuestoinnaireTypeName")
			->join("ClinicPerson", "ClinicPerson.PersonId = CustomQuestionnaires.PersonId", null)
			->where("ClinicPerson.ClinicId = ?", $clinicId)
			->where("ClinicPerson.RoleId = ?", $roleId)
			->where("ClinicPerson.Deleted=0")
			->where("IsActive=1")
			->where("IsGrouped=0")
			->order("NameText.Name");

		$rows=$qTbl->fetchAll($select);
		$questionnaires=array();
		foreach($rows as $row)
		{
			$q = new Questionnaire();
			$q->getDataByDBRow($row);
			
			$questionnaires[]=$q;
		}
		
		return $questionnaires;
	}
	
	private function returnHasSummaries()
	{
		$this->hasSummaries=false;
		if($this->questionnaireId == null){
			throw new Exception("QuestionnaireId is null.");
		}else{
			$sTbl=new SectionTable();
			$select=$sTbl->select()->distinct()->setIntegrityCheck(false)->from("Section", "*")
			->join("Question", "Question.SectionId = Section.SectionId", null)
			->where("Section.QuestionnaireId = ?", $this->questionnaireId)
			->where("Question.SummaryTitleId IS NOT NULL");
			
			$rows=$sTbl->fetchAll($select);
			if(count($rows)>0)
				$this->hasSummaries=true;
			else
				$this->hasSummaries=false;
			
		}
		return $this->hasSummaries;
	}
	
	private function returnTags() {
		if(!is_numeric($this->questionnaireId)){
			$this->tags = array();
			return $this->tags;
		}
		//Get all the tags for a questionnaire
		$this->tags = QuestionnaireTag::fetchDataByQuestionnaireId($this->questionnaireId);
		
		//iterate through the tag to find the primary tag.  first tag found marked as primary will be considered the primary.	
		foreach($this->tags as $tag){
			if($tag->isPrimary == 1) {
				$this->primaryTag = $tag->tag;
				$this->primaryColorCode = $tag->colorCode;
				break;
			}
		}
		//return the tags as an array of QuestionnaireTag objects
		return $this->tags;
	}
	
	public static function getAllQuestionnairesByAppointmentId($appointmentId){
		
		$appointmentId = (int)$appointmentId;
		
		$questionnaires=array();
		$qTbl=new QuestionnaireTable();
		
		if(!empty($appointmentId)){

			$select=$qTbl->select()->setIntegrityCheck(false)->distinct(true)
			->from(array("S"=>"Sessions"),null)
			->joinLeft(array('Q'=>'Questionnaire'),'S.QuestionnaireId=Q.QuestionnaireId')
			->joinLeft(array('QT'=>'QuestionnaireTags'),'Q.QuestionnaireId=QT.QuestionnaireId AND QT.IsPrimary = 1', null)
			->joinLeft(array('T'=>'Tags'),'QT.TagId=T.TagId')
			->joinLeft(array('NT'=>'NameText'),'Q.NameTextId=NT.NameTextId',array('Name'))
			->joinLeft(array('DT'=>'DescriptionText'),'Q.DescriptionTextId=DT.DescriptionTextId',array('Description'))
			->joinLeft(array('QType'=>'QuestionnaireType'),'Q.QuestionnaireTypeId=QType.QuestionnaireTypeId',array('QuestionnaireType'=>'Name'))
			->where("S.IsDeleted=0")
			->where("S.AppointmentId=?",$appointmentId)
			->order("Q.QuestionnaireTypeId")
			->order("IF((T.Tag='specialty'),0,1)")
			->order("T.TagId");
			
			$rows=$qTbl->fetchAll($select);
	
			
			foreach($rows as $row)
			{
				$questionnaire = new Questionnaire();
				$questionnaire->getDataByDBRow($row);
				$questionnaire->primaryTag=$row->Tag;
				if(!empty($row->ColorCode))
					$questionnaire->primaryColorCode=$row->ColorCode;
				$questionnaires[$row->QuestionnaireId]=$questionnaire;
			}
				
		}
		return $questionnaires;

	}
	public static function searchOnName($term,$questionnaireTypeId=null,$limit=10){
        $qTbl=new QuestionnaireTable();
        $count = 0;
        $searchTerm = '%'.strtolower($term).'%';
        $select=$qTbl->select()
                ->from('Questionnaire',array('COUNT(*) AS Count'))
                ->setIntegrityCheck(false)
                ->joinLeft(array('NT'=>'NameText'),'NT.NameTextId=Questionnaire.NameTextId',array('Name'))
                ->where('LOWER(NT.Name) LIKE ?',$searchTerm);
        if($questionnaireTypeId !== null){
            $select->where('Questionnaire.QuestionnaireTypeId=?',$questionnaireTypeId);
        }
        $res = $qTbl->fetchAll($select);
        $count = $res->current()->Count;
        $select=$qTbl->select()
                        ->from('Questionnaire',array('QuestionnaireId','NameTextId','QuestionnaireTypeId'))
                        ->setIntegrityCheck(false)
                        ->joinLeft(array('NT'=>'NameText'),'NT.NameTextId=Questionnaire.NameTextId',array('Name'))
                        ->where('LOWER(NT.Name) LIKE ?',$searchTerm);
        if($questionnaireTypeId !== null){
            $select->where('Questionnaire.QuestionnaireTypeId=?',$questionnaireTypeId);
        }
        if($limit > 0){
            $select->limit($limit);
        }
        $out = array('count'=>$count,'results'=>array(),'term'=>$term);
        $res2 = $qTbl->fetchAll($select);
        foreach($res2 as $qrow){
            $out['results'][] = $qrow->toArray();
        }
        return $out;
    }
}
?>