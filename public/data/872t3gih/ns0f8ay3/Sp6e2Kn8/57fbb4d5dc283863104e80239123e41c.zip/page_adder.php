<?php
if($line_coo<= 70)
    {
        $page_id++;
        $page = $pdf -> newPage(Zend_Pdf_page::SIZE_A4);
        $pdf -> pages[$page_id] = $page;
        require 'header.php';
        require 'footer.php';
        $line_coo = 750;
        //$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
    }
?>
 
