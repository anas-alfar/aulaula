<?php
//error_reporting(E_ALL);
//ini_set('display_errors',1);
//date_default_timezone_set('Asia/Manila');
require_once 'email_attachment.php';
echo '<center>';
echo '<font face="verdana"><b>E-mail PDF Questionnaire</b></font><br><br>';

echo '<form action = "send_mail.php" method = "post">';

echo  '<textarea rows="1" cols="50" name ="mail_address">';
echo $_POST['mail_address'];
echo '</textarea>';

echo '&nbsp <input type="submit"  value="&nbsp Email &nbsp" name="EmailForm" /> <br><br>';
require_once 'db_connect.php';

$query_Questionnaire  = "SELECT * FROM Questionnaire";
$result_Questionnaire = mysql_query($query_Questionnaire)or die(mysql_error());
$row_split = 0;
echo '<table border="0.1" width="100%">';
        while($row_Questionnaire = mysql_fetch_array($result_Questionnaire, MYSQL_ASSOC))
        {
           $query_Questionnaire_text  = "SELECT * FROM NameText WHERE NameTextId =".$row_Questionnaire['NameTextId'];
           $result_Questionnaire_text = mysql_query($query_Questionnaire_text)or die(mysql_error());
            while($row_Questionnaire_text = mysql_fetch_array($result_Questionnaire_text, MYSQL_ASSOC))
            {
                $title_email[$row_Questionnaire['QuestionnaireId']] = $row_Questionnaire_text['Name'];
            }
        }
//asort($title_email);
foreach($title_email as $key => $print_title )
{
    if($row_split % 4);
    else echo '<tr>';
    echo '<td>';
    echo '<font face="Arial" size="2"><input type="checkbox" name="Select_to_mail[]" value="'.$key.'" />'.$print_title;
    echo '&nbsp['.$key.']';
    echo '</font>';
    echo '</td>';
    $row_split++;
}
echo '</table>';
echo '</form>';
echo '</center>';
$selected_mail = $_POST['Select_to_mail'];
if(isset($_POST['Select_to_mail']))
{
    foreach($selected_mail as $se)
    {
       require 'Pdf_page.php';
       $sendit = new AttachmentEmail($_POST['mail_address'],$title_email[$se],'', 'pdf/'.$se.'.pdf');
       $sendit -> mail();
       echo '<font face="verdana" color="green"><b>'.$title_email[$se].'&nbsp Has been sent </b></font><br>';
    }
}
$mailIt = 1;

?>
 
