<?php
require 'db_connect.php';
$query_get_scale  = "SELECT * FROM QuestionScale WHERE QuestionId=".$questionId[$question_type_index].";";
$result_scale = mysql_query($query_get_scale)or die(mysql_error());
$row_scale = mysql_fetch_array($result_scale)or die(mysql_error());

$query_get_nameText_start  = "SELECT * FROM NameText WHERE NameTextId=".$row_scale['StartNameTextId'].";";
$result_get_nameText_start = mysql_query($query_get_nameText_start)or die(mysql_error());
$row_get_nameText_start = mysql_fetch_array($result_get_nameText_start)or die(mysql_error());

$query_get_nameText_end  = "SELECT * FROM NameText WHERE NameTextId=".$row_scale['EndNameTextId'];
$result_get_nameText_end = mysql_query($query_get_nameText_end)or die(mysql_error());
$row_get_nameText_end = mysql_fetch_array($result_get_nameText_end)or die(mysql_error());

$scale_coo =  strlen($row_get_nameText_start['Name'])*4 + 200;
$x1 =  130;
if($questionIsAlternative[$question_type_index]==1)  //if is alternative question
{
    $scale_coo= $scale_coo+10;
    $x1=140;
}
$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 9);
$page -> drawText($row_scale['StartValue'],120,$line_coo,'UTF-8');
$page -> drawText($row_scale['EndValue'],$scale_coo,$line_coo,'UTF-8');
$y1 =  $line_coo + 5;
$y2 =  $line_coo + 1;

$x2 =  $scale_coo -5;
$page->setLineWidth(1);
//$page -> drawRectangle($x1, $y1, $x2, $y2,$fillType = Zend_Pdf_Page::SHAPE_DRAW_STROKE);
$page -> drawLine($x1,$line_coo + 5,$x1,$line_coo + 1);
$page -> drawLine($x1,$line_coo+3,$scale_coo-10,$line_coo+3);
$page -> drawLine($scale_coo-10,$line_coo + 5,$scale_coo-10,$line_coo +1);

$line_coo = $line_coo-20;
require 'page_adder.php';
$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 8);
$page -> drawText($row_get_nameText_start['Name'],120,$line_coo,'UTF-8');
$page -> drawText($row_get_nameText_end['Name'],$scale_coo,$line_coo,'UTF-8');
$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 9);
?>
 
