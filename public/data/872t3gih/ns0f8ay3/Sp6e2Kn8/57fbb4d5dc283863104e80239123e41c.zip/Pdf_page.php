<?php

require_once("../init.php");
require_once("../dbinit.php");
include("../sslcheck.php"); //make sure we have an SSL connection if we want one

require_once 'Zend/Pdf.php';
require_once 'db_connect.php';
require_once '../business/Questionnaire.php';
require_once 'Zend/Debug.php';
require_once 'get_questionnaire.php';

//require_once 'interface.php';
//select * from question q inner join section s on q.SectionId = s.SectionId where s.QuestionnaireId = 382;
$questionnaire_number = $se;

require 'get_all_question.php';

//$get_q = new get_questionnaire($questionnaire_number);

//$get_q_function =  $get_q -> solve_array();

//$messages = $get_q -> questionText;
//$questionTypes = $get_q -> questionType;
//$questionId = $get_q -> questionId;
//$sectionId = $get_q -> sectionId;

$line_coo = 750;
$page_id = 1;

$pdf = new Zend_Pdf();
$page = $pdf -> newPage(Zend_Pdf_page::SIZE_A4);
$pdf -> pages[$page_id] = $page;

require 'header.php';
require 'footer.php';

require'print_pdf_handler.php';

$pdf -> save('pdf/'.$se.'.pdf');
//$pdfData = $pdf -> render();
/*--------------------------------------------------------*/
unset($messages);
unset($questionId);
unset($sectionId);
unset($questionTypes);

?>
