<?php
$foot_msg1 = 'Copyright 2010 Universal Research Solutions           123 South 8th St. Columbia, MO 65201       573.442.7101   Fax: 573.442.7149';


$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 8);
$page -> drawText($foot_msg1,50,50,'UTF-8');

//Draw line
$page->setLineWidth(1);
$page -> drawLine(50,70,545,70);

?>
 
