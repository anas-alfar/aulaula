<?php

// Set headers
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename=Questionnaire.pdf');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
ini_set('zlib.output_compression','0');

// Get File Contents and echo to output
echo file_get_contents("pdf/Questionnaire.pdf");

// Prevent anything else from being outputted
die();

?>
 
