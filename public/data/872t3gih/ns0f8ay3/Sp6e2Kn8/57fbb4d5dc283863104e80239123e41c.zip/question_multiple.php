<?php
require 'db_connect.php';
 $query_get_multiple  = "SELECT * FROM QuestionMultipleChoice WHERE QuestionId=".$questionId[$question_type_index].";";
//echo $query_get_multiple  = "SELECT * FROM QuestionMultipleChoice WHERE QuestionId=".$questionId[$question_type_index].";";

 $result_multiple = mysql_query($query_get_multiple)or die(mysql_error());
 $row_multiple = mysql_fetch_array($result_multiple);//or die(mysql_error());

//var_dump($row_multiple);
if ($row_multiple == false) { echo 'mmmmm'; return; }

 $query_get_multipleChoice  = "SELECT NameTextId FROM MultipleChoice WHERE MultipleChoiceGroupId=".$row_multiple['MultipleChoiceGroupId'];
 $result_get_multipleChoice = mysql_query($query_get_multipleChoice)or die(mysql_error());
//echo __LINE__ . '<br />';
$inter = 90;
if($questionIsAlternative[$question_type_index]==1)  //if is alternative question
{
    $inter=100;
}
while($row_1 = mysql_fetch_array($result_get_multipleChoice, MYSQL_ASSOC))
{
    $m_y1 =  $line_coo + 8;
    $m_y2 =  $line_coo - 2;
    $m_x1 =  $inter - 14;
    $m_x2 =  $inter - 4;
    $query_get_option_Text  = "SELECT * FROM NameText WHERE NameTextId=".$row_1['NameTextId'];

    $result_get_option_Text = mysql_query($query_get_option_Text)or die(mysql_error());
    $row_get_option_Text = mysql_fetch_array($result_get_option_Text)or die(mysql_error());
    $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 9);
    /*-----------------------------------------------------------------*/
       $option_text = wordwrap($row_get_option_Text['Name'],95,"|");
       $optArr = explode("|",$option_text);
       /*---------------------------------------------*/
       foreach($optArr as $wrappedOpt)
       {
           /*-------------------- Draw rectangle for options ----------------------*/
           $page->setLineWidth(0.5);
           $page -> drawRectangle($m_x1, $m_y1, $m_x2, $m_y2,$fillType = Zend_Pdf_Page::SHAPE_DRAW_STROKE);
           $page->setLineWidth(1);
           /*-----------------------------------------------------------------------*/
           $page -> drawText($wrappedOpt,$inter,$line_coo,'UTF-8'); 
           require 'page_adder.php';

           if(strlen($row_get_option_Text['Name'])>30) $inter = $inter + strlen($row_get_option_Text['Name'])*3 + 100;
           if(strlen($row_get_option_Text['Name'])<=30) $inter = $inter + strlen($row_get_option_Text['Name']) + 120;
           if($inter > 350)
           {
               $inter = 90;
              if($questionIsAlternative[$question_type_index]==1)  //if is alternative question
              {
                   $inter=100;
              }
              $line_coo = $line_coo - 20;
               require 'page_adder.php';
           }
       }
}
require 'page_adder.php';

?>
 
