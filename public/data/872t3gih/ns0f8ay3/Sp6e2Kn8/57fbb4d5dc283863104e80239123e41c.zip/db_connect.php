<?php

		//mysql_connect('50.57.134.202', 'root', 'max2labmysql?') or die(mysql_error());
		mysql_connect('127.0.0.1', 'root', 'root') or die(mysql_error());
		mysql_select_db('medadatonline_demo') or die(mysql_error());
/*
class Database
{
	const db_source = "medadatonline_demo";

}
*/
?>
 
