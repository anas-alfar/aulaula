<?php

$msg_problem_details = array(
        'questionText' => $this->returned_q[$sectionID][$parent_qID][$questionID]->questionText,
        'questionType' => $this->returned_q[$sectionID][$parent_qID][$questionID]->questionType,
        'questionId' => $this->returned_q[$sectionID][$parent_qID][$questionID]->questionId,
        'nameTextId' => $this->returned_q[$sectionID][$parent_qID][$questionID]->nameTextId,
        'sectionId' => $this->returned_q[$sectionID][$parent_qID][$questionID]->sectionId,
        'questionTypeId' => $this->returned_q[$sectionID][$parent_qID][$questionID]->questionTypeId,
        );
require_once 'db_connect.php';
//PDF
//$messages = $this->returned_q[$sectionID][$parent_qID][$questionID]->questionText;

$this -> questionText[$this->index2] =  $this->returned_q[$sectionID][$parent_qID][$questionID]->questionText;
$this->index2++;

$this -> questionType[$this->index3] =  $this->returned_q[$sectionID][$parent_qID][$questionID]->questionType;
$this->index3++;

$this -> questionId[$this->index4] =  $this->returned_q[$sectionID][$parent_qID][$questionID]->questionId;
$this->index4++;

$this -> sectionId[$this->index5] =  $this->returned_q[$sectionID][$parent_qID][$questionID]->sectionId;
$this->index5++;
/*
$query  = "SELECT NameTextId FROM Question WHERE QuestionId=" . $this->returned_q[$sectionID][$parent_qID][$questionID]->questionId;
$result = mysql_query($query)or die(mysql_error());


while($row = mysql_fetch_array($result))
{
    print_r($row);
}
*/
$problem_container = array();
  $problem_container[$this->index] =  $msg_problem_details;
   $this->index++;
//print_r($problem_container);
//Zend_Debug::dump($problem_container);


//Zend_Debug::dump($returned_q);
?>
 
