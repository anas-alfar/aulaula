<?php

require_once("../init.php");
require_once("../dbinit.php");
include("../sslcheck.php");


require_once 'db_connect.php';
echo '<center>PDF Questionnaire </center><br>';
$query_Questionnaire  = "SELECT * FROM Questionnaire";

$result_Questionnaire = mysql_query($query_Questionnaire)or die(mysql_error());

echo '<center>';
/*--------------- E- mail --------------------*/
echo '<form action = "interface.php" method = "post">';
echo '<input type="submit" name ="email_page" value="&nbsp Email &nbsp" />';

echo '</form>';
if(isset($_POST['email_page']))header('Location: send_mail.php');
/*------------------------------------------------*/
echo '</center>';
echo '<center>';
echo '<table border="0.1" width="2000">';
echo '<form action = "interface.php" method = "post">';
$row_split = 0;
//$title_index = 0;
while($row_Questionnaire = mysql_fetch_array($result_Questionnaire, MYSQL_ASSOC))
{
   $query_Questionnaire_text  = "SELECT * FROM NameText WHERE NameTextId =".$row_Questionnaire['NameTextId'];
   $result_Questionnaire_text = mysql_query($query_Questionnaire_text)or die(mysql_error());
    while($row_Questionnaire_text = mysql_fetch_array($result_Questionnaire_text, MYSQL_ASSOC))
    {
        $title[$row_Questionnaire['QuestionnaireId']] = $row_Questionnaire_text['Name'];
    }
}
asort($title);
foreach($title as $key => $print_title )
{
    if($row_split % 4);
    else echo '<tr>';
    echo '<td>';
    echo '<input type="checkbox" name="Select[]" value="'.$key.'" />'.$print_title.'';
    echo '&nbsp &nbsp['.$key.']';
    echo '</td>';
    $row_split++;
}

echo '<center><input type="submit" value="&nbsp Save &nbsp" />';
echo '</form>';
echo '</table>';
echo '</center>';

$selected = $_POST['Select'];
if(isset($_POST['Select']))
{
    foreach($selected as $se)
    {
       echo $se;
       echo '<br>';
       require 'Pdf_page.php';
       //$pdf2 = Zend_Pdf::load('../pdf/'.$se.'.pdf');
    }

}
$mailIt = 0;
$title = 'TITLE';
?>
 
