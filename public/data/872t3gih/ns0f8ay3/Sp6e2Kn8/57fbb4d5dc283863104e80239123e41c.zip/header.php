<?php
// Load image

$imagePath = 'images/logo.png';
$image = Zend_Pdf_Image::imageWithPath($imagePath);
// Draw image
$page->drawImage($image,50,770, 145, 805);
//$page->drawImage($image, $left, $bottom, $right, $top);

//Draw line
$page->setLineWidth(1);
$page -> drawLine(50,765,545,765);

$page_number = 'Page '.$page_id;

$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 8);
$page -> drawText($page_number,500,800,'UTF-8');



?>
 
