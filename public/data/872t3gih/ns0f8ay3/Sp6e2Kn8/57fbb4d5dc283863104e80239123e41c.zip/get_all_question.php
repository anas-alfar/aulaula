<?php
$query_get_alternative = "SELECT Q.QuestionId AS QuestionId, NT.Name AS QuestionText, QT.Name AS QuestionType,
         Q.SectionId AS SectionId, Q.SectionId, Q.Rank, Q.IsAlternative,Q.HasAlternative
         FROM Question Q
         INNER JOIN Section S ON S.SectionId = Q.SectionId
         INNER JOIN NameText NT ON NT.NameTextId = Q.NameTextId
         INNER JOIN QuestionType QT ON QT.QuestionTypeId = Q.QuestionTypeId
         WHERE Q.IsAlternative!=1 AND S.QuestionnaireId = ".$se." ORDER BY SectionId, Rank ";
         
       
         
         
         

//$q = "select * from question q inner join section s on q.SectionId = s.SectionId where s.QuestionnaireId =".$se;
$result_get_alternative = mysql_query($query_get_alternative)or die(mysql_error());

$index_al = 0;
while($row_al = mysql_fetch_array($result_get_alternative))
{
   $messages[$index_al] =  $row_al['QuestionText'];
   //echo $messages[$index_al];
   //echo $index_al."<br>";
   $questionId[$index_al] =  $row_al['QuestionId'];
   $sectionId[$index_al] =  $row_al['SectionId'];
   $questionTypes[$index_al] = $row_al['QuestionType'];
   $questionHasAlternative[$index_al] = $row_al['HasAlternative'];
   $questionIsAlternative[$index_al] = $row_al['IsAlternative'];
    if($row_al['HasAlternative']==1)  //if HasAlternative pull out all the child question Id
    {
        $query_get_ChildQuestion = "SELECT * FROM AlternativeQuestion WHERE ParentQuestionId=".$row_al['QuestionId'];
        $result_get_ChildQuestion = mysql_query($query_get_ChildQuestion)or die(mysql_error());
        while($row_get_child = mysql_fetch_array($result_get_ChildQuestion)) //for each child question get there content
        {
            $index_al++; //get each child question detail
            $query_pull_ChildQuestion ="SELECT Q.QuestionId AS QuestionId, NT.Name AS QuestionText, QT.Name AS QuestionType,
                     Q.SectionId AS SectionId, Q.SectionId, Q.Rank, Q.IsAlternative,Q.HasAlternative
                     FROM Question Q
                     INNER JOIN Section S ON S.SectionId = Q.SectionId
                     INNER JOIN NameText NT ON NT.NameTextId = Q.NameTextId
                     INNER JOIN QuestionType QT ON QT.QuestionTypeId = Q.QuestionTypeId
                     WHERE Q.QuestionId =".$row_get_child['ChildQuestionId'] ;
            $result_pull_ChildQuestion = mysql_query($query_pull_ChildQuestion)or die(mysql_error());
            $row_pull_child =mysql_fetch_array($result_pull_ChildQuestion);
            //fill each child question detail into the main array
            $messages[$index_al] =  $row_pull_child['QuestionText'];
            // echo $messages[$index_al];
            //echo $index_al."<br>";
            $questionId[$index_al] =  $row_pull_child['QuestionId'];
            $sectionId[$index_al] =  $row_pull_child['SectionId'];
            $questionTypes[$index_al] = $row_pull_child['QuestionType'];
            $questionHasAlternative[$index_al] = $row_pull_child['HasAlternative'];
            $questionIsAlternative[$index_al] = $row_pull_child['IsAlternative'];
                
                  // Another level of child questions
                  
                    if($row_pull_child['HasAlternative']==1)  //if HasAlternative pull out all the child question Id
    			{

						$query_get_ChildQuestion1 = "SELECT * FROM AlternativeQuestion WHERE ParentQuestionId=".$row_pull_child['QuestionId'];
						$result_get_ChildQuestion1 = mysql_query($query_get_ChildQuestion1)or die(mysql_error());
						while($row_get_child1 = mysql_fetch_array($result_get_ChildQuestion1)) //for each child question get there content
						{
							$index_al++; //get each child question detail
							$query_pull_ChildQuestion1 ="SELECT Q.QuestionId AS QuestionId, NT.Name AS QuestionText, QT.Name AS QuestionType,
									 Q.SectionId AS SectionId, Q.SectionId, Q.Rank, Q.IsAlternative,Q.HasAlternative
									 FROM Question Q
									 INNER JOIN Section S ON S.SectionId = Q.SectionId
									 INNER JOIN NameText NT ON NT.NameTextId = Q.NameTextId
									 INNER JOIN QuestionType QT ON QT.QuestionTypeId = Q.QuestionTypeId
									 WHERE Q.QuestionId =".$row_get_child1['ChildQuestionId'] ;
							$result_pull_ChildQuestion1 = mysql_query($query_pull_ChildQuestion1)or die(mysql_error());
							$row_pull_child1 =mysql_fetch_array($result_pull_ChildQuestion1);
							//fill each child question detail into the main array
							$messages[$index_al] =  $row_pull_child1['QuestionText'];
							// echo $messages[$index_al];
							// echo $index_al."<br>";
							$questionId[$index_al] =  $row_pull_child1['QuestionId'];
							$sectionId[$index_al] =  $row_pull_child1['SectionId'];
							$questionTypes[$index_al] = $row_pull_child1['QuestionType'];
							$questionHasAlternative[$index_al] = $row_pull_child1['HasAlternative'];
							$questionIsAlternative[$index_al] = $row_pull_child1['IsAlternative'];
							
													if($row_pull_child1['HasAlternative']==1)  //if HasAlternative pull out all the child question Id
										{
						
												$query_get_ChildQuestion2 = "SELECT * FROM AlternativeQuestion WHERE ParentQuestionId=".$row_pull_child1['QuestionId'];
												$result_get_ChildQuestion2 = mysql_query($query_get_ChildQuestion2)or die(mysql_error());
												while($row_get_child2 = mysql_fetch_array($result_get_ChildQuestion2)) //for each child question get there content
												{
													$index_al++; //get each child question detail
													$query_pull_ChildQuestion2 ="SELECT Q.QuestionId AS QuestionId, NT.Name AS QuestionText, QT.Name AS QuestionType,
															 Q.SectionId AS SectionId, Q.SectionId, Q.Rank, Q.IsAlternative,Q.HasAlternative
															 FROM Question Q
															 INNER JOIN Section S ON S.SectionId = Q.SectionId
															 INNER JOIN NameText NT ON NT.NameTextId = Q.NameTextId
															 INNER JOIN QuestionType QT ON QT.QuestionTypeId = Q.QuestionTypeId
															 WHERE Q.QuestionId =".$row_get_child2['ChildQuestionId'] ;
													$result_pull_ChildQuestion2 = mysql_query($query_pull_ChildQuestion2)or die(mysql_error());
													$row_pull_child2 =mysql_fetch_array($result_pull_ChildQuestion2);
													//fill each child question detail into the main array
													$messages[$index_al] =  $row_pull_child2['QuestionText'];
													// echo $messages[$index_al];
													// echo $index_al."<br>";
													$questionId[$index_al] =  $row_pull_child2['QuestionId'];
													$sectionId[$index_al] =  $row_pull_child2['SectionId'];
													$questionTypes[$index_al] = $row_pull_child2['QuestionType'];
													$questionHasAlternative[$index_al] = $row_pull_child2['HasAlternative'];
													$questionIsAlternative[$index_al] = $row_pull_child2['IsAlternative'];
												  }
												}
						  }
						}
						//echo $index_al;
          
        }
    }
   $index_al++;
}
$index_al = 0;
    /*
     SELECT Q.QuestionId AS QuestionId, NT.Name AS QuestionText, QT.Name AS QuestionType,
         Q.SectionId AS SectionId
         FROM Question Q
         INNER JOIN Section S ON S.SectionId = Q.SectionId
         INNER JOIN NameText NT ON NT.NameTextId = Q.NameTextId
         INNER JOIN QuestionType QT ON QT.QuestionTypeId = Q.QuestionTypeId
         WHERE S.QuestionnaireId = 115;
     */

?>
 
