<?php
$yn_y1 =  $line_coo + 8;
$yn_y2 =  $line_coo - 2;
$yn_x1 =  76;
$yn_x2 =  86;
$xx1 = 156;
$xx2 = 166;
$yes_coo =90;
$no_coo =170;
if($questionIsAlternative[$question_type_index]==1)  //if is alternative question
{
    $yn_x1 = $yn_x1+10;
    $yn_x2 =  $yn_x2+10;
    $xx1 = $xx1+10;
    $xx2 =  $xx2+10;
    $yes_coo =$yes_coo+10;
    $no_coo =$no_coo+10;
}
/*-------------------- Draw rectangle for options ----------------------*/
    $page->setLineWidth(0.5);
    $page -> drawRectangle($yn_x1, $yn_y1, $yn_x2, $yn_y2,$fillType = Zend_Pdf_Page::SHAPE_DRAW_STROKE);
    $page -> drawRectangle($xx1, $yn_y1, $xx2, $yn_y2,$fillType = Zend_Pdf_Page::SHAPE_DRAW_STROKE);
    $page->setLineWidth(1);
/*-----------------------------------------------------------------------*/

$page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 9);
$page -> drawText('Yes',$yes_coo,$line_coo,'UTF-8');
$page -> drawText('No',$no_coo,$line_coo,'UTF-8');

require 'page_adder.php';
?>
 
