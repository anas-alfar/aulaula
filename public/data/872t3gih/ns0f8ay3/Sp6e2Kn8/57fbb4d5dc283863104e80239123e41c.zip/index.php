<?php
header('Location:send_mail.php');
	
?>