<?php
echo '<center>';
echo '<br>';
echo '<font face="verdana"><b>URS PDF Questionnaire Form</b></font><br><br>';
echo '<form action = "director.php" method = "post">';
echo '<br><br>';

echo '<input type="submit" value="&nbsp Email &nbsp " name="eSubmit"/><br><br>';
echo '<input type="submit" value="&nbsp&nbsp Save &nbsp&nbsp" name="sSubmit"/><br>';

echo '</form>';

if(isset($_POST['eSubmit']))
{
    header('Location:send_mail.php');
}
if(isset($_POST['sSubmit']))
{
    header('Location:interface.php');
}


?>
 
