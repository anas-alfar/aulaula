<?php
 /* $query_get_section  = "SELECT * FROM Section
       INNER JOIN NameText ON NameText.NameTextId=Section.NameTextId
       INNER JOIN InstructionsText ON Section.InstructionsTextId=InstructionsText.InstructionsTextId
   WHERE QuestionnaireId=".$se;   */

    $query_get_section  = "SELECT * FROM Section WHERE QuestionnaireId=".$se;

   $result = mysql_query($query_get_section);
   $sec_instruct_i = 0;
    while($row = mysql_fetch_array($result))
    {
	    if($row['NameTextId']!=NULL)
        {
            $query_get_section_text = "SELECT Name FROM NameText WHERE NameTextId=".$row['NameTextId'];
            $result_get_section_text = mysql_query($query_get_section_text);
            $row_get_section_text = mysql_fetch_array($result_get_section_text);
            //get instruction text & put it into Instruction_Array
            $Section_Array[$sec_instruct_i]= $row_get_section_text['Name'];
        }
        if($row['NameTextId']==NULL)
        {
            $Section_Array[$sec_instruct_i]= '';
        }

        if($row['InstructionsTextId']!=NULL)
        {
            $query_get_Instruction_text = "SELECT Instructions FROM InstructionsText WHERE InstructionsTextId=".$row['InstructionsTextId'];
            $result_get_Instruction_text = mysql_query($query_get_Instruction_text);
            $row_get_Instruction_text = mysql_fetch_array($result_get_Instruction_text);
            //get instruction text & put it into Instruction_Array
            $Instruction_Array[$sec_instruct_i] = $row_get_Instruction_text['Instructions'];
        }
        if($row['InstructionsTextId']==NULL)
        {
            $Instruction_Array[$sec_instruct_i]='';
        }
        $sec_instruct_i++;
    }

  if($temp_section != $sectionId[$section_index])
  {
      $section_num++;
    $question_index = 1;
    $line_coo = $line_coo-20;
    require 'page_adder.php';
    $page->setFillColor(Zend_Pdf_Color_Html::color('#00537C'));//#00537C
    $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
   /*____________________________________________________________*/
		$sec_max_line_length = 95; //line length

        $sec_line_start_coo = 56; //Where the question start
    /*___________________________________________________*/

    $sec_wrap = wordwrap($Section_Array[$index_all],$sec_max_line_length,"|");
    $sec_Arr = explode("|",$sec_wrap);
    $instruct_wrap = wordwrap($Instruction_Array[$index_all],$sec_max_line_length,"|");
    $instruct_Arr = explode("|",$instruct_wrap);
    foreach($sec_Arr as $wrappedSec)
    {
        $page->setFillColor(Zend_Pdf_Color_Html::color('#00537C'));
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
        $page -> drawText(substr($wrappedSec, 0,$sec_max_line_length),$sec_line_start_coo,$line_coo,'UTF-8');
        $line_coo = $line_coo-20;//start new line
        require 'page_adder.php';
    }

    foreach($instruct_Arr as $wrappedInstruct)
    {
        $page->setFillColor(Zend_Pdf_Color_Html::color('#00537C'));
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
        $page -> drawText(substr($wrappedInstruct, 0,$sec_max_line_length),$sec_line_start_coo,$line_coo,'UTF-8');
        $line_coo = $line_coo-20;//start new line
        require 'page_adder.php';
    }
    require 'page_adder.php';
    $temp_section = $sectionId[$section_index];
    $temp_instruction = $row['Instructions'];
    $page->setFillColor(Zend_Pdf_Color_Html::color('#000000'));
    $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 10);
    $index_all++;
  }

?>
 
