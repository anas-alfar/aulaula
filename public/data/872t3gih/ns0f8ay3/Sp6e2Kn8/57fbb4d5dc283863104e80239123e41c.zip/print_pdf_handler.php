<?php
$question_index = 1;
$question_type_index = 0;
$temp_section = '';
$temp_instruction = '';
$section_num = 0;
$index_all = 0;
$subindex=0;

 $query_get_section  = "SELECT * FROM Section
       INNER JOIN NameText ON NameText.NameTextId=Section.NameTextId
       INNER JOIN InstructionsText ON Section.InstructionsTextId=InstructionsText.InstructionsTextId
   WHERE QuestionnaireId=".$se;

   $result = mysql_query($query_get_section);
   $sec_instruct_i = 0;
    while($row = mysql_fetch_array($result))
    {
	   $Instruction_Array[$sec_instruct_i] = $row['Instructions'];
        $Section_Array[$sec_instruct_i] = $row['Name'];
        
        echo   $Section_Array[$sec_instruct_i]."<br>";
        
        $sec_instruct_i++;
    }


$query_Questionnaire_title  = "SELECT NameTextId FROM Questionnaire WHERE QuestionnaireId =".$se;
//$q = "select * from question q inner join section s on q.SectionId = s.SectionId where s.QuestionnaireId =".$se;
$result_Questionnaire_title = mysql_query($query_Questionnaire_title)or die(mysql_error());
while($row_Questionnaire_title = mysql_fetch_array($result_Questionnaire_title, MYSQL_ASSOC))
{
  //echo  $alternative_question_index;

   $query_Questionnaire__title_text  = "SELECT * FROM NameText WHERE NameTextId =".$row_Questionnaire_title['NameTextId'];
   $result_Questionnaire__title_text = mysql_query($query_Questionnaire__title_text)or die(mysql_error());
    while($row_Questionnaire__title_text = mysql_fetch_array($result_Questionnaire__title_text, MYSQL_ASSOC))
    {
    echo $row_Questionnaire__title_text['Name']."<br>";
        $page->setFillColor(Zend_Pdf_Color_Html::color('#005C8A')); //#086A87
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 11);
        $page -> drawText($row_Questionnaire__title_text['Name'],65,750,'UTF-8');
    }
}

$line_coo =  $line_coo - 20;

$section_index =0;
//print_r($messages);
//echo "<br>";
foreach($messages as $msg)
{
//echo $section_index;
    /* ------------------ print out section ------------------------- */
    $sectionId[$question_type_index];
   // echo $sectionId[$question_type_index];
    require 'section_handler.php';
    
    $line_coo = $line_coo-20;
    require 'page_adder.php';
    
  
  
  
    /*----------------------------- index number --------------------------*/ 
        if($questionIsAlternative[$question_type_index]==1)  //if is alternative question use different index number and different line start
    {
        $max_line_length = 78; //line length
        $line_start_coo = 90; //Where the question start

        if($alternative_question_index==1)//print alternative question text before the first child question
        {
            $page->setFillColor(Zend_Pdf_Color_Html::color('#104E8B')); //#086A87
            $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
            $page -> drawText('Alternative Question',65,$line_coo,'UTF-8');
            $line_coo = $line_coo-20;
            require 'page_adder.php';
        }
        $page->setFillColor(Zend_Pdf_Color_Html::color('#104E8B')); //#086A87
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);

        if($alternative_question_index>9)$page -> drawText($alternative_question_index,75,$line_coo,'UTF-8');
               else $page -> drawText($alternative_question_index,81,$line_coo,'UTF-8');
               $page->setFillColor(Zend_Pdf_Color_Html::color('#000000'));
        $alternative_question_index++;
        $question_index--; //question index not change
        
        }
        
       
        
    /*------------------------index number-------------------------------------*/
    if($questionIsAlternative[$question_type_index]!=1)// if is not alternative use normal format
    {
        $question_index_i = $section_num.'.'.$question_index;
        $page->setFillColor(Zend_Pdf_Color_Html::color('#005C8A')); //#086A87
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
        if($question_index>9)$page -> drawText($question_index_i,55,$line_coo,'UTF-8');
        else $page -> drawText($question_index_i,61,$line_coo,'UTF-8');
        $page->setFillColor(Zend_Pdf_Color_Html::color('#000000'));

        $max_line_length = 88; //line length
        $line_start_coo = 80; //Where the question start
        $alternative_question_index=1;

    }
    /*-----------------------------------------------------------------*/
    $msg = strip_tags($msg); //remove html tags
    $msg = wordwrap($msg,$max_line_length,"|");
    $msgArr = explode("|",$msg);
    /*---------------------------------------------*/
    //print_r( $msgArr);
    foreach($msgArr as $wrappedMsg)
    {
        $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA_BOLD), 10);
        $page -> drawText(substr($wrappedMsg, 0,$max_line_length),$line_start_coo,$line_coo,'UTF-8');
        $line_coo = $line_coo-20;//start new line
        require 'page_adder.php';
    }

    $page->setFont(Zend_Pdf_Font::fontWithName(Zend_Pdf_Font::FONT_HELVETICA), 9);
    //$page -> drawText($questionTypes[$question_type_index],$line_start_coo,$line_coo,'UTF-8');
    if($questionTypes[$question_type_index] =='Scale')require 'question_scale.php';
    if($questionTypes[$question_type_index] =='MultipleChoice')require 'question_multiple.php';
    if($questionTypes[$question_type_index] =='YesNo')require 'question_yesno.php';
    if($questionTypes[$question_type_index] =='MultipleChoiceWithChooseAllThatApply')require 'question_multiple.php';
    $question_type_index++;
    $line_coo = $line_coo-20;
    require 'page_adder.php';
    $question_index++;
    $section_index++;
//echo $index_all;
    unset($row_section);

}


?>
 
